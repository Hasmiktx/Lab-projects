
import './App.css'
import Button from './components/Button'

function App() {
  

  return (
    <div className="App">
      <Button text="Send" variant="secondary" width={100} height={80}/> 
     
    </div>
  )
}

export default App
